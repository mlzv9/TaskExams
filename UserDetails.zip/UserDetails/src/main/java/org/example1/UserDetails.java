package org.example1;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class UserDetails {

    WebDriver webDriver;

    public UserDetails(WebDriver webDriver){
        this.webDriver = webDriver;
        PageFactory.initElements(webDriver, this);
    }


    @FindBy(xpath = "/html/body/div[3]/div[2]/div[2]/div[2]/div[2]/button[1]/p")
    WebElement noticeButton;

    @FindBy(xpath = "//*[@id=\"menu-item-50\"]/a")
    WebElement clickMyAccountButton;

    @FindBy(xpath = "//*[@id=\"username\"]")
    WebElement loginEmailField;

    @FindBy(xpath = "//*[@id=\"password\"]")
    WebElement passwordField;

    @FindBy(xpath = "//*[@id=\"customer_login\"]/div[1]/form/p[3]/input[3]")
    WebElement loginButton;

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/nav/ul/li[5]/a")
    WebElement accountDetailsButton;

    @FindBy(xpath = "//*[@id=\"account_email\"]")
    WebElement emailFieldAccountDetails;

    @FindBy(id = "account_first_name")
    WebElement firstNameField;

    @FindBy(id = "account_last_name")
    WebElement lastNameField;

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div/form/p[4]/input[3]")
    WebElement saveChangesButton;

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div[1]")
    WebElement successfullySavedMessage;

    public void clickAcceptCookie(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(noticeButton)).click();
    }
    public void clickMyAccountButton(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(clickMyAccountButton)).click();
    }
    public void enterEmail(String email){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(loginEmailField)).sendKeys(email);
    }
    public void enterPassword(String pass){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));

        for(char symbol : pass.toCharArray()){
            try {
                Thread.sleep(250);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            wait.until(ExpectedConditions.visibilityOf(passwordField)).sendKeys(Character.toString(symbol));
        }


    }
    public void clickLoginButton(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();

    }
    public void clickAccountDetails(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(accountDetailsButton)).click();
    }
    public String getEmailFromAccount(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(emailFieldAccountDetails));
        emailFieldAccountDetails.click();
         String currentEmail = emailFieldAccountDetails.getAttribute("value");
        return currentEmail;


    }
    public void enterFirstName(String firstName){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        firstNameField.clear();
        wait.until(ExpectedConditions.visibilityOf(firstNameField)).sendKeys(firstName);

    }
    public void enterLastName(String lastName){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        lastNameField.clear();
        wait.until(ExpectedConditions.visibilityOf(lastNameField)).sendKeys(lastName);

    }
    public String getFirstName(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(firstNameField));
        return firstNameField.getAttribute("value");


    }
    public String getLastName(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(lastNameField));
        return lastNameField.getAttribute("value");
    }
    public void clickSaveChangesButton(){



        JavascriptExecutor js = (JavascriptExecutor) webDriver;
        js.executeScript(
                "var rect = arguments[0].getBoundingClientRect();" +
                        "window.scrollTo(0, window.scrollY + rect.top - 50);", saveChangesButton
        );
        saveChangesButton.click();


    }
    public String getMessages(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));

        return  wait.until(ExpectedConditions.visibilityOf(successfullySavedMessage)).getText();

    }

}
