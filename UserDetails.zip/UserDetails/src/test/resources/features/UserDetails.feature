Feature: Check in my account details


  Scenario Outline: 1. Check for correct email is used i my account details
    Given the user open web page
    When the user click MyAccount button
    And the user enter email "<email>" in login email field
    And the user enter password "<password>" in login password field
    And the user click login buttoon
    And the user click Account Details button
    Then the email "<emailCheck>" must be correctly

    Examples:
    |email            |password      |emailCheck   |
    |USer445500@abv.bg|paSs137ffFPf! |USer445500@abv.bg|

    Scenario Outline: 2.The user would like to enter first and last names, make sure they are correct in the input boxes, and save.
      Given the user is the accountDetails page
      When the user enter firstName "<firstName>"
      And the user enter lastName "<lastName>"
      And click save changes button
      Then the input first name "<firstName>" and last name "<lastName>" should be displayed message "<expectedMessage>" for successfully saved changes

      Examples:
      |firstName|lastName | expectedMessage                      |
      |Jonh     | Jonhson | Account details changed successfully.|