package org.example1;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class UserDetailsTest {

    private static WebDriver webDriver;

    private static UserDetails userDetails;

    @BeforeAll
    public static void setup(){
        ChromeOptions options = new ChromeOptions().addArguments(Constants.START_MAXIMIZED_CHROME);

        webDriver = new ChromeDriver(options);
        userDetails = new UserDetails(webDriver);
    }

    @AfterAll
    public static void close(){
        webDriver.close();
        webDriver.quit();
    }

    @Given("the user open web page")
    public void the_user_open_web_page() {
        try {
            webDriver.get(Constants.WEB_SITE_URL);
            userDetails.clickAcceptCookie();
        }catch (Exception e){
            System.out.println("Error: Something went wrong! " + e.getMessage());
        }
    }
    @When("the user click MyAccount button")
    public void the_user_click_my_account_button() {
        try {
            userDetails.clickMyAccountButton();
        }catch (Exception e){
            System.out.println("Error: Something went wrong! " + e.getMessage());
        }
    }
    @When("the user enter email {string} in login email field")
    public void the_user_enter_email_in_login_email_field(String email) {
        try {
            userDetails.enterEmail(email);
        }catch (Exception e){
            System.out.println("Error: Something went wrong! " + e.getMessage());
        }

    }
    @When("the user enter password {string} in login password field")
    public void the_user_enter_password_in_login_password_field(String password) {
        try {
            userDetails.enterPassword(password);
        }catch (Exception e){
            System.out.println("Error: Something went wrong! " + e.getMessage());
        }
    }
    @When("the user click login buttoon")
    public void the_user_click_login_buttoon() {
        try {
            userDetails.clickLoginButton();
        }catch (Exception e){
            System.out.println("Error: Something went wrong! " + e.getMessage());
        }
    }
    @When("the user click Account Details button")
    public void the_user_click_account_details_button() {
        try {
            userDetails.clickAccountDetails();
        }catch (Exception e){
            System.out.println("Error: Something went wrong! " + e.getMessage());
        }
    }
    @Then("the email {string} must be correctly")
    public void the_email_must_be_correctly(String expectedEmail) {

       String currentEmail = userDetails.getEmailFromAccount();
       if(currentEmail.isEmpty()){
           throw new AssertionError("Error: The current email is null! ");
       }


       Assertions.assertEquals(expectedEmail, currentEmail, "Error: The current email is not the same with expected email! the current email are: " + currentEmail);
    }

    @Given("the user is the accountDetails page")
    public void the_user_is_the_account_details_page() {
        String url = webDriver.getCurrentUrl();
        Assertions.assertTrue(url.contains("edit-account"), "Error: The user is not the edit-account page! Current page is: " + url);
    }
    @When("the user enter firstName {string}")
    public void the_user_enter_first_name(String firstName) {
        userDetails.enterFirstName(firstName);

    }
    @When("the user enter lastName {string}")
    public void the_user_enter_last_name(String lastName) {
        userDetails.enterLastName(lastName);
    }
    @When("click save changes button")
    public void click_save_changes_button() {
        userDetails.clickSaveChangesButton();
    }


    @Then("the input first name {string} and last name {string} should be displayed message {string} for successfully saved changes")
    public void the_input_first_name_and_last_name_should_be_displayed_message_for_successfully_saved_changes(String firstName, String lastName, String expectedMess) {
        String getMessages = userDetails.getMessages();
        Assertions.assertEquals(expectedMess, getMessages, "Error: The changes is not saved! the message is: " + getMessages);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        userDetails.clickAccountDetails();

        String getFirstName = userDetails.getFirstName();
        String getLastName = userDetails.getLastName();


        Assertions.assertEquals(firstName , getFirstName, "Error: The first name is not correct! the incorrect first name is: " + getFirstName);
        Assertions.assertEquals(lastName , getLastName, "Error: The last name is not correct! the incorrect last  name is: " + getLastName);
    }

}
