package org.example1;


import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class RegistrationTest {

    private static WebDriver webDriver;
    private static WebDriverWait wait;
    private static Registration regSteps;

    private static final String email = "jonhSmiTh1990@uk.com";
    private static final String password = "SmItH2sA910Ku@15";

    @BeforeAll
    public static void setup(){
        ChromeOptions options = new ChromeOptions().addArguments(Constants.START_MAXIMIZED_CHROME);
        webDriver = new ChromeDriver(options);
        wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        regSteps = new Registration(webDriver,wait);
    }

    @AfterAll
    public static void close(){
        webDriver.close();
        webDriver.quit();
    }


    @Given("the user open home web page")
    public void the_user_open_home_web_page() {

       try{
           webDriver.get(Constants.WEB_SITE_URL);
           Assertions.assertTrue(regSteps.getCurrentUrl().contentEquals(Constants.WEB_SITE_URL), "Error: The web page is not correct!");

       }catch (NullPointerException e){
           System.out.println("Error: " + e.getMessage());
       }
    }

    @When("the user decline private notice")
    public void the_user_decline_private_notice() {
        regSteps.declinePrivateNotice();
    }

    @When("the user input valid email and password")
    public void the_user_input_valid_email_and_password() {
        regSteps.clickMyAccountButton();
        String url = regSteps.getCurrentUrl();
        Assertions.assertTrue(url.contains("my-account"), "Error: The user is not in the registration page!");
        regSteps.inputEmail(email);
        regSteps.inputPassword(password);
        regSteps.enterRegButton();

    }

    @Then("the user is correct registered")
    public void the_user_is_correct_registered() {
      String response = regSteps.checkForCorrectReg();
      String emailUsedToReg = email.split("@")[0];
      Assertions.assertTrue(response.contains(emailUsedToReg), "Error: The user is not registered!");


    }
}
