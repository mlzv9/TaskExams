Feature: Registration with valid data


  Scenario: 1.Testing registration form with valid data
    Given the user open home web page
    When  the user decline private notice
    And the user input valid email and password
    Then the user is correct registered
