package org.example1;

public class Constants {
    public static final String WEB_SITE_URL = "https://practice.automationtesting.in/";
    public static final String START_MAXIMIZED_CHROME = "Start-Maximized";
    public static final String SLIDES_IN_HOME_PAGE_XPATH = "//img[contains(@class, 'n2-ss-slide-background-image')]";
    public static final String MY_ACCOUNT_BUTTON_XPATH = "//*[@id=\"menu-item-50\"]/a";
    public static final String REGISTER_FIELD_EMAIL_XPATH = "//*[@id=\"reg_email\"]";
    public static final String REGISTER_FILED_PASSWORD_XPATH = "//*[@id=\"reg_password\"]";
    public static final String REGISTER_BUTTON_XPATH = "//*[@id=\"customer_login\"]/div[2]/form/p[3]/input[3]";
    public static final String INPUT_EMAIL = "USer444ss@abv.bg";
    public static final String INPUT_PASSWORD = "paSs137ffFPf3s!";
    public static final String WELCOME_MESSAGE_IN_SUCCESSFULLY_REGISTRATION_XPATH = "//*[@id=\"page-36\"]/div/div[1]/div/p[1]";

    public static final String ACCEPT_NOTICE_XPATH = "/html/body/div[3]/div[2]/div[2]/div[2]/div[2]/button[1]/p";
    public static final String DECLINE_PRIVATE_NOTICE = "/html/body/div[3]/div[2]/div[2]/div[2]/div[2]/button[2]/p";
    public static final String MESSAGE_REGISTRATION_WITH_USED_EMAIL_AND_PASS_XPATH = "//*[@id=\"page-36\"]/div/div[1]/ul/li";
    public static final String EXPECTED_MESSAGE_FOR_REG_EXISTING_USER = "Error: An account is already registered with your email address. Please login.";
    public static final String MESSAGE_VERY_WEEK_PASS_XPATH = "//*[@id=\"customer_login\"]/div[2]/form/p[2]/div";

    public static final String LOGIN_EMAIL_FIELD_XPATH = "//*[@id=\"username\"]";
    public static final String LOGIN_PASSWORD_FIELD_XPATH = "//*[@id=\"password\"]";
    public static final String LOGIN_BUTTON_XPATH = "//*[@id=\"customer_login\"]/div[1]/form/p[3]/input[3]";
    public static final String ACCOUNT_DETAILS_BUTTON_XPATH = "//*[@id=\"page-36\"]/div/div[1]/nav/ul/li[5]/a";
    public static final String EMAIL_FIELD_ACCOUNT_DETAILS_XPATH = "//*[@id=\"account_email\"]";

    public static final String FIRST_NAME_FILED_XPATH = "//*[@id=\"account_first_name\"]";
    public static final String LAST_NAME_FIELD_XPATH = "//*[@id=\"account_last_name\"]";
    public static final String SAVE_CHANGES_XPATH = "//*[@id=\"page-36\"]/div/div[1]/div/form/p[4]/input[3]";
    public static final String SUCCESSFULLY_SAVED_CHANGES_XPATH = "//*[@id=\"page-36\"]/div/div[1]/div[1]";
}
