package org.example1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Registration {


    private final WebDriverWait wait;
    private final WebDriver webDriver;
    public Registration(WebDriver webDriver , WebDriverWait wait){
        this.wait = wait;
        this.webDriver = webDriver;
    }

    public void declinePrivateNotice(){

        WebElement declineButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Constants.DECLINE_PRIVATE_NOTICE)));
        declineButton.click();
    }
    public void inputEmail(String email){

        WebElement inputEmail = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Constants.REGISTER_FIELD_EMAIL_XPATH)));
        inputEmail.sendKeys(email);
    }
    public void inputPassword(String passwordInput){
        WebElement inputPassword = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Constants.REGISTER_FILED_PASSWORD_XPATH)));

        for(char symbol : passwordInput.toCharArray()){
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            inputPassword.sendKeys(Character.toString(symbol));
        }

    }
    public void enterRegButton(){
        WebElement regButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Constants.REGISTER_BUTTON_XPATH)));
        regButton.click();
    }

    public String checkForCorrectReg(){
        WebElement messageForWelcome = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Constants.WELCOME_MESSAGE_IN_SUCCESSFULLY_REGISTRATION_XPATH)));
         return messageForWelcome.getText();
    }
    public String getCurrentUrl(){
       return webDriver.getCurrentUrl();

    }
    public void clickMyAccountButton(){
        WebElement myAccountButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Constants.MY_ACCOUNT_BUTTON_XPATH)));
        myAccountButton.click();
    }
}
