Feature: user update shipping address


  Scenario: 1.The user checked is shipping address is entry and enter address data
    Given the user is successfully login
    When the user is not enter before shipping address
    And the user input shipping addres
    Then the user is successfully saved sipping address
    And the user is successfully logged out



