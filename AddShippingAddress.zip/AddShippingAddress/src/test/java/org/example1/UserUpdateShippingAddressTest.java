package org.example1;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class UserUpdateShippingAddressTest {

    private static WebDriver webDriver;
    private static WebDriverWait wait;
    private static Login login;
    private static UserUpdateShippingAddress shippingAddress;

    private static final String expectedMessForEntryAddress = "You have not set up this type of address yet.";
    private static final String email = "ivanPetrov1988@gmail.com";
    private static final String password = "IvAnPe8891!aBaC";
    private static final String firstName = "Ivan";
    private static final String lastName = "Petrov";
    private static final String countryName = "Bulgaria";
    private static final String streetAddress = "Byl.V.Vazov 12";
    private static final String townName = "Varna";
    private static final String zipCode = "1920";
    private static final String stateName = "Varna";
    private static final String expectedMessageForSuccessSavingChanges = "Address changed successfully.";


    @BeforeAll
    public static void setup(){
        ChromeOptions options = new ChromeOptions();
        options.addArguments("Start-Maximized");
        webDriver = new ChromeDriver(options);
        wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        login = new Login();
        shippingAddress = new UserUpdateShippingAddress(webDriver);
        webDriver.get("https://practice.automationtesting.in/");

    }
    @AfterAll
    public static void close(){
        webDriver.close();
        webDriver.quit();
    }


    @Given("the user is successfully login")
    public void the_user_is_successfully_login() {
        login.getLogin(webDriver, wait, email, password);
        try {
            String currentUrl = webDriver.getCurrentUrl();
            Assertions.assertTrue(currentUrl.contains("my-account"), "Error: The user is not success loggedIn!");
        }catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }
    @When("the user is not enter before shipping address")
    public void the_user_is_not_enter_before_shipping_address() {
        shippingAddress.clickAddressButton(wait);
        String currentMessages = shippingAddress.getMessageForEntryShippingAddress(wait);
        Assertions.assertFalse(currentMessages.isEmpty(), "Error: The message is not found! current message is: " + currentMessages);
        Assertions.assertEquals(expectedMessForEntryAddress.trim(), currentMessages.trim(), "Error: the user have input shipping address! the current address si: " + currentMessages);

    }
    @When("the user input shipping addres")
    public void the_user_input_shipping_addres() {
        shippingAddress.clickEditShippingButton(wait);
        try{
            String currentUrl = webDriver.getCurrentUrl();
            Assertions.assertTrue(currentUrl.contains("shipping"), "Error: the user is not in shipping address  page! current url is: " + currentUrl);
        }catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
        try {
            shippingAddress.enterFirstName(wait, firstName);
            shippingAddress.enterLastName(wait, lastName);
            shippingAddress.enterCountryName(wait, countryName);
            shippingAddress.enterStreetAddress(wait, streetAddress);
            shippingAddress.enterTownName(webDriver, wait, townName);
            shippingAddress.enterZipCode(wait, zipCode);
            shippingAddress.enterState(wait, stateName);
            shippingAddress.clickSAveButton(wait);
        }catch (Exception e ){
            System.out.println("Error: In input shipping address! current Error is:  " + e.getMessage());
        }

    }
    @Then("the user is successfully saved sipping address")
    public void the_user_is_successfully_saved_sipping_address() {
        try {
            String url = webDriver.getCurrentUrl();
            Assertions.assertTrue(url.contains("my-account"), "Error: The user is not saved changes , the user is on shipping address page! current url is: " + url);
        }catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
       String currentMess = shippingAddress.getMessageAfterSavingAddress(wait);
       Assertions.assertEquals(expectedMessageForSuccessSavingChanges.trim(), currentMess.trim(), "Error: The changed is not saving! current message is: " + currentMess);

    }
    @Then("the user is successfully logged out")
    public void the_user_is_successfully_logged_out() {
        shippingAddress.clickSignOutButton(wait);
        shippingAddress.getHeadForLogin(wait);
        Assertions.assertTrue(shippingAddress.getHeadForLogin(wait).trim().equalsIgnoreCase("Login"), "Error: The user is not logged Out!");

    }




}
