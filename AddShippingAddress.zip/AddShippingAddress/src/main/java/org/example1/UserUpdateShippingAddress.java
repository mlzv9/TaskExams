package org.example1;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UserUpdateShippingAddress {

    WebDriver webDriver;

    public UserUpdateShippingAddress(WebDriver webDriver){
        this.webDriver = webDriver;
        PageFactory.initElements(webDriver,  this);
    }

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div/div/div[2]/header/a")
    WebElement editButtonForShippingAddress;

    public void clickEditShippingButton(WebDriverWait wait){
        wait.until(ExpectedConditions.elementToBeClickable(editButtonForShippingAddress)).click();
    }

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div/div/div[2]/address")
    WebElement messageForEntryAddress;

    public String getMessageForEntryShippingAddress(WebDriverWait wait){

       return wait.until(ExpectedConditions.visibilityOf(messageForEntryAddress)).getText();
    }
    @FindBy(xpath = "//*[@id=\"shipping_first_name\"]")
    WebElement firstNameFiled;
    @FindBy(xpath = "//*[@id=\"shipping_last_name\"]")
    WebElement lastNameField;
    @FindBy(xpath = "//*[@id=\"select2-chosen-1\"]")
    WebElement countryNameButton;
    @FindBy(xpath = "//*[@id=\"s2id_autogen1_search\"]")
    WebElement countryNameField;
    @FindBy(xpath = "//*[@id=\"shipping_address_1\"]")
    WebElement streetAddressField;
    @FindBy(xpath = "//*[@id=\"shipping_city\"]")
    WebElement townNameField;
    @FindBy(xpath = "//*[@id=\"shipping_postcode\"]")
    WebElement zipCodeField;
    @FindBy(xpath = "//*[@id=\"s2id_shipping_state\"]/a/span[2]/b")
    WebElement stateButton;

    @FindBy(xpath = "//*[@id=\"s2id_autogen2_search\"]")
    WebElement stateField;

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div/form/p[10]/input[1]")
    WebElement saveAddressButton;

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div[1]")
    WebElement saveChangesMessage;

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/nav/ul/li[4]/a")
    WebElement addressButton;

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div[2]/p[1]/a")
    WebElement signOutButton;

    @FindBy(xpath = "//*[@id=\"customer_login\"]/div[1]/h2")
    WebElement loginHeadHomePage;
    public void enterFirstName(WebDriverWait wait, String firstName){
        wait.until(ExpectedConditions.visibilityOf(firstNameFiled)).sendKeys(firstName);
    }
    public void enterLastName(WebDriverWait wait, String lastName){
        wait.until(ExpectedConditions.visibilityOf(lastNameField)).sendKeys(lastName);
    }
    public void enterCountryName(WebDriverWait wait, String countryName){
        wait.until(ExpectedConditions.elementToBeClickable(countryNameButton)).click();
        wait.until(ExpectedConditions.visibilityOf(countryNameField)).sendKeys(countryName, Keys.ENTER);
    }
    public void enterStreetAddress(WebDriverWait wait, String streetAddress){
        wait.until(ExpectedConditions.visibilityOf(streetAddressField)).sendKeys(streetAddress);
    }

    public void enterTownName(WebDriver webDriver, WebDriverWait wait, String townName){
        wait.until(ExpectedConditions.visibilityOf(townNameField));
        JavascriptExecutor js = (JavascriptExecutor) webDriver;
        js.executeScript("var rect = arguments[0].getBoundingClientRect();" +
                "window.scrollTo(0, window.pageYOffset + rect.top - 100);", townNameField);
        townNameField.sendKeys(townName);
    }
    public void enterZipCode(WebDriverWait wait, String zipCode){
        wait.until(ExpectedConditions.visibilityOf(zipCodeField)).sendKeys(zipCode);
    }
    public void enterState(WebDriverWait wait, String state){
        wait.until(ExpectedConditions.elementToBeClickable(stateButton)).click();
        wait.until(ExpectedConditions.visibilityOf(stateField)).sendKeys(state, Keys.ENTER);

    }
    public void clickSAveButton(WebDriverWait wait){
        wait.until(ExpectedConditions.elementToBeClickable(saveAddressButton)).click();
    }
    public String getMessageAfterSavingAddress(WebDriverWait wait){

        wait.until(ExpectedConditions.visibilityOf(saveChangesMessage));
        return saveChangesMessage.getText();
    }
    public void clickAddressButton(WebDriverWait wait){
        wait.until(ExpectedConditions.elementToBeClickable(addressButton)).click();
    }
    public void clickSignOutButton(WebDriverWait wait){
        wait.until(ExpectedConditions.elementToBeClickable(signOutButton)).click();
    }
    public String getHeadForLogin(WebDriverWait wait){

         wait.until(ExpectedConditions.visibilityOf(loginHeadHomePage));
         return loginHeadHomePage.getText();


    }
}
