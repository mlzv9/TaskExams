Feature: Registration with existing username and password


  Scenario Outline:1.Registration with existing username and password
    Given the user open  web page
    When the user accept  cookies
    And  the user click MyAccount button in home page
    And the user enter existing email "<email>" in registration email field
    And the user enter existing pass "<password>" in registration pass field
    And the user click register button in registration page
    Then should be displayed message for existing registered user

    Examples:
    |email            |password      |
    |USer445500@abv.bg|paSs137ffFPf! |

