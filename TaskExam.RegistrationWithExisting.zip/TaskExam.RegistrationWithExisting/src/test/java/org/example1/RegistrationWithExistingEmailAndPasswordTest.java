package org.example1;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class RegistrationWithExistingEmailAndPasswordTest {

     private static WebDriver webDriver;
     private static WebDriverWait wait;
     private static RegistrationWithPreviouslyData reg;

     @BeforeAll
     public static void setup(){
         ChromeOptions options = new ChromeOptions().addArguments(Constants.START_MAXIMIZED_CHROME);
         webDriver = new ChromeDriver(options);
         wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
         reg = new RegistrationWithPreviouslyData(webDriver);


     }
     @AfterAll
     public static void close(){
         webDriver.close();
         webDriver.quit();
     }
    @Given("the user open  web page")
    public void the_user_open_web_page() {
        webDriver.get(Constants.WEB_SITE_URL);
    }
    @When("the user accept  cookies")
    public void the_user_accept_cookies() {
        reg.acceptNoticeClick();
    }
    @When("the user click MyAccount button in home page")
    public void the_user_click_my_account_button_in_home_page() {
        reg.clickMyAccountButton();
    }
    @When("the user enter existing email {string} in registration email field")
    public void the_user_enter_existing_email_in_registration_email_field(String existEmail) {
         reg.enterEmail(existEmail);

    }
    @When("the user enter existing pass {string} in registration pass field")
    public void the_user_enter_existing_pass_in_registration_pass_field(String existPassword) {
        reg.enterPassword(existPassword);
    }
    @When("the user click register button in registration page")
    public void the_user_click_register_button_in_registration_page() {
       reg.clickRegButton();
    }
    @Then("should be displayed message for existing registered user")
    public void should_be_displayed_message_for_existing_registered_user() {


        String currentMessage = reg.getMessage();
        String expectedMes = Constants.EXPECTED_MESSAGE_FOR_REG_EXISTING_USER;
        Assertions.assertEquals(expectedMes.trim(), currentMessage.trim(), "Error: The message is not was expected!");
    }



}
