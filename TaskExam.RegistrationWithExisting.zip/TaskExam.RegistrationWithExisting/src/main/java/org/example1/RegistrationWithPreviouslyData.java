package org.example1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class RegistrationWithPreviouslyData {

    WebDriver webDriver;

    public RegistrationWithPreviouslyData(WebDriver webDriver){
        this.webDriver = webDriver;
        PageFactory.initElements(webDriver , this);

    }

    @FindBy(xpath = "/html/body/div[3]/div[2]/div[2]/div[2]/div[2]/button[1]/p")
    WebElement acceptPrivateNoticeButton;

    @FindBy(xpath = "//*[@id=\"menu-item-50\"]/a")
    WebElement myAccountButton;

    @FindBy(xpath = "//*[@id=\"reg_email\"]")
    WebElement emailRegField;

    @FindBy(xpath = "//*[@id=\"reg_password\"]")
    WebElement passRegField;

    @FindBy(xpath = "//*[@id=\"customer_login\"]/div[2]/form/p[3]/input[3]")
    WebElement registerButton;

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/ul/li")
    WebElement getMessageFroExistingUser;

    public void clickMyAccountButton(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(myAccountButton)).click();

    }
    public void acceptNoticeClick(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(acceptPrivateNoticeButton)).click();

    }
    public void enterEmail(String email){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(emailRegField)).sendKeys(email);

    }
    public void enterPassword(String pass){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));

        for(char symbol : pass.toCharArray()){
            try {
                Thread.sleep(250);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            wait.until(ExpectedConditions.visibilityOf(passRegField)).sendKeys(Character.toString(symbol));
        }
    }
    public void clickRegButton(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(registerButton)).click();
        registerButton.click();
    }
    public String getMessage(){
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(getMessageFroExistingUser));

        return getMessageFroExistingUser.getText();
    }
}
