package org.example1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Login {




    public void getLogin( WebDriver webDriver, WebDriverWait wait ,String email , String password){


        WebElement acceptNotice = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Constants.ACCEPT_NOTICE_XPATH)));
        acceptNotice.click();


        WebElement myAccountButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Constants.MY_ACCOUNT_BUTTON_XPATH)));
        myAccountButton.click();

        WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Constants.LOGIN_EMAIL_FIELD_XPATH)));
        emailField.sendKeys(email);

        WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Constants.LOGIN_PASSWORD_FIELD_XPATH)));
        passwordField.sendKeys(password);

        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Constants.LOGIN_BUTTON_XPATH)));
        loginButton.click();


    }

}
