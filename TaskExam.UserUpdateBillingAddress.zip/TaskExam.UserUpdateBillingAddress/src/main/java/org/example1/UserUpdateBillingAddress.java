package org.example1;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class UserUpdateBillingAddress {


    WebDriver webDriver;

    public UserUpdateBillingAddress(WebDriver webDriver){
        this.webDriver = webDriver;
        PageFactory.initElements(webDriver, this);
    }

    @FindBy(xpath = "/html/body/div[3]/div[2]/div[2]/div[2]/div[2]/button[1]/p")
    WebElement acceptPrivateNotice;

    public void acceptNotice(WebDriverWait wait){
        try {
            wait.until(ExpectedConditions.elementToBeClickable(acceptPrivateNotice));
            if (acceptPrivateNotice.isDisplayed()) {
                acceptPrivateNotice.click();
            } else {
                System.out.println("Error: The button is not displayed!");
            }
        }catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    @FindBy(xpath = "//*[@id=\"menu-item-50\"]/a")
    WebElement myAccountButton;

    public void clickMyAccountButton(WebDriverWait wait){
        wait.until(ExpectedConditions.elementToBeClickable(myAccountButton));
        try {
            if(myAccountButton.isDisplayed()){
                myAccountButton.click();
            }else{
                System.out.println("Error: The button is not displayed!");
            }



        }catch (Exception e){
            System.out.println("Error: " + e.getMessage());

        }
    }

    @FindBy(xpath = "//*[@id=\"username\"]")
    WebElement loginEmailField;

    public void enterEmailInLoginFiled(WebDriverWait wait, String email){
        wait.until(ExpectedConditions.visibilityOf(loginEmailField)).sendKeys(email);
    }

    @FindBy(xpath = "//*[@id=\"password\"]")
    WebElement loginPasswordField;

    public void enterPasswordInLoginField(WebDriverWait wait, String password){
        wait.until(ExpectedConditions.visibilityOf(loginPasswordField)).sendKeys(password);
    }

    @FindBy(xpath = "//*[@id=\"customer_login\"]/div[1]/form/p[3]/input[3]")
    WebElement loginButton;

    public void clickLoginButton(WebDriverWait wait){
        wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
    }

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/nav/ul/li[4]/a")
    WebElement addressButton;


    public void clickAddressButton(WebDriverWait wait){
        wait.until(ExpectedConditions.elementToBeClickable(addressButton)).click();
    }

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div/div/div[1]/address")
    WebElement billingAddressMessage;

    public String getBillingAddressMessage(WebDriverWait wait){
        return   wait.until(ExpectedConditions.visibilityOf(billingAddressMessage)).getText();
    }

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div/div/div[1]/header/a")
    WebElement editButton;

    public void clickEditButton(WebDriverWait wait){
        wait.until(ExpectedConditions.elementToBeClickable(editButton)).click();
    }

    @FindBy(xpath = "//*[@id=\"select2-chosen-1\"]")
    WebElement countryChoice;
    @FindBy(xpath = "//*[@id=\"s2id_autogen1_search\"]")
    WebElement fieldForInputCountry;

    public void enterCountry(WebDriverWait wait, String country){
        wait.until(ExpectedConditions.elementToBeClickable(countryChoice)).click();
        wait.until(ExpectedConditions.visibilityOf(fieldForInputCountry)).sendKeys(country, Keys.ENTER);

    }

    @FindBy(xpath = "//*[@id=\"billing_address_1\"]")
    WebElement streetInputField;

    public void inputStreetAddress(WebDriverWait wait, String streetAddress){
        wait.until(ExpectedConditions.visibilityOf(streetInputField)).sendKeys(streetAddress);
    }

    @FindBy(xpath = "//*[@id=\"billing_city\"]")
    WebElement townFieldForInput;

    public void enterTownName(WebDriver webDriver,WebDriverWait wait,  String town){
        wait.until(ExpectedConditions.visibilityOf(townFieldForInput));
        JavascriptExecutor js = (JavascriptExecutor) webDriver;
        js.executeScript("var rect = arguments[0].getBoundingClientRect();" +
                "window.scrollTo(0, window.pageYOffset + rect.top - 100);", townFieldForInput);
        townFieldForInput.sendKeys(town);
    }

    @FindBy(xpath = "//*[@id=\"billing_postcode\"]")
    WebElement postcodeFieldForInput;

    public void enterPostcode(WebDriverWait wait , String postcode){
        wait.until(ExpectedConditions.visibilityOf(postcodeFieldForInput)).sendKeys(postcode);
    }

    @FindBy(xpath = "//*[@id=\"select2-chosen-2\"]")
    WebElement provinceButton;

    @FindBy(xpath = "//*[@id=\"s2id_autogen2_search\"]")
    WebElement provinceFieldForInput;

    public void enterProvince(WebDriverWait wait, String province){
        wait.until(ExpectedConditions.elementToBeClickable(provinceButton)).click();
        wait.until(ExpectedConditions.visibilityOf(provinceFieldForInput)).sendKeys(province, Keys.ENTER);

    }
    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div/form/p[12]/input[1]")
    WebElement saveAddressButton;

    public void clickSaveAddressButton(WebDriverWait wait){
        wait.until(ExpectedConditions.elementToBeClickable(saveAddressButton)).click();

    }

    @FindBy(xpath = "//*[@id=\"billing_first_name\"]")
    WebElement firstNameField;
    public void enterFirstName(WebDriverWait wait, String firstName){
        wait.until(ExpectedConditions.visibilityOf(firstNameField)).sendKeys(firstName);


    }

    @FindBy(xpath = "//*[@id=\"billing_last_name\"]")
    WebElement lastNameField;

    public void enterLastName(WebDriverWait wait, String lastName){
        wait.until(ExpectedConditions.visibilityOf(lastNameField)).sendKeys(lastName);
    }

    @FindBy(xpath = "//*[@id=\"billing_phone\"]")
    WebElement phoneNumberField;

    public void enterPhoneNumber(WebDriverWait wait, String phoneNumber){
        wait.until(ExpectedConditions.visibilityOf(phoneNumberField)).sendKeys(phoneNumber);
    }

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div[1]")
    WebElement messageAfterSaveAddress;

    public String getMessAfterSaveAddress(WebDriverWait wait){

        wait.until(ExpectedConditions.visibilityOf(messageAfterSaveAddress));
        if(webDriver.getCurrentUrl().contains("my-account")){
            return messageAfterSaveAddress.getText();
        }
        return "Error: the user is on address page ! ";
    }

    @FindBy(xpath = "//*[@id=\"page-36\"]/div/div[1]/div/p[1]")
    WebElement messageForSuccessLoggedIn;
    public String getMessageForSuccessfullyLogin(WebDriverWait wait){
        wait.until(ExpectedConditions.visibilityOf(messageForSuccessLoggedIn));
        return messageForSuccessLoggedIn.getText();
    }




}
