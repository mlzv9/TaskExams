package org.example1;

import org.junit.jupiter.api.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class UserUpdateBillingAddressTest {

    private static WebDriver webDriver;
    private static WebDriverWait wait;
    private static Login login;
    private static UserUpdateBillingAddress userUpdateAddress;
    private static final String email = "petroVFIvan1988@gmail.com";
    private static final String password = "mYPaSSPetRoFf!gMail";
    private static final String expectedBillingMessageForEntryAddress = "You have not set up this type of address yet.";
    private static final String country = "Italy";
    private static final String streetAddress = "Piazza del Colosseo, 1, 001843 Roma RM";
    private static final String town = "Rome";
    private static final String postcode = "100232211";
    private static final String province = "Trento";
    private static final String firstName = "Jonh";
    private static final String lastName = "Jonhson";
    private static final String phoneNumber = "0023452111230";
    private static final String expectedMessAfterSuccessSavedAddress = "Address changed successfully.";


    @BeforeAll
    public static void setup(){
        ChromeOptions options = new ChromeOptions();
        options.addArguments("Start-Maximized");
        webDriver = new ChromeDriver(options);
        wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        userUpdateAddress = new UserUpdateBillingAddress(webDriver);
        webDriver.get("https://practice.automationtesting.in/");

        login = new Login();
        login.getLogin(webDriver, wait, email, password);
        try {
            login.getLogin(webDriver, wait, email, password);
            Assertions.assertTrue(userUpdateAddress.getMessageForSuccessfullyLogin(wait).contains(email.split("@")[0]),"Error: The user is not in home page!");
        }catch (Exception e){
            System.out.println("The something was wrong! -> " + e.getMessage() );
        }


    }
    @AfterAll
    public static void close(){
        webDriver.close();
        webDriver.quit();
    }


    @Test
    @Order(1)
    @DisplayName("navigate to his address and verify is not set")
    public void checkAddressVerifyAreNotSet(){

        userUpdateAddress.clickAddressButton(wait);
        try {
            String url = webDriver.getCurrentUrl();
            Assertions.assertTrue(url.contains("edit-address"), "Error: The user is not is address page!");
        }catch (Exception e){
            System.out.println("Something was wrong  " + e.getMessage());
        }
        String getMessageBillingAddress = userUpdateAddress.getBillingAddressMessage(wait);
        Assertions.assertFalse(getMessageBillingAddress.isEmpty(),
                "Error: The billing address message is not found!");
        Assertions.assertTrue(expectedBillingMessageForEntryAddress.trim().equals(getMessageBillingAddress.trim()),
                "Error: The user have input address! the current message is: " + getMessageBillingAddress);



    }

    @Test
    @Order(2)
    @DisplayName("set billing address and check for successfully saved")
    public void setBillingAddressCheckForSaved(){
        userUpdateAddress.clickEditButton(wait);
        try{
            String url = webDriver.getCurrentUrl();
            assert url != null;
            Assertions.assertTrue(url.contains("billing"), "Error: The user is not a billing address page!");
        }catch (Exception e){
            System.out.println("The something was wrong " + e.getMessage());
        }
        userUpdateAddress.enterLastName(wait, lastName);
        userUpdateAddress.enterFirstName(wait, firstName);
        userUpdateAddress.enterCountry(wait, country);
        userUpdateAddress.enterPhoneNumber(wait, phoneNumber);
        userUpdateAddress.inputStreetAddress(wait, streetAddress);
        userUpdateAddress.enterTownName(webDriver, wait, town);
        userUpdateAddress.enterPostcode(wait, postcode);
        userUpdateAddress.enterProvince(wait, province);
        userUpdateAddress.clickSaveAddressButton(wait);












    }
    @Test
    @Order(3)
    @DisplayName("check for successfully saved address")
    public void checkForSuccessSavedAddress(){

        Assertions.assertEquals(expectedMessAfterSuccessSavedAddress.trim(), userUpdateAddress.getMessAfterSaveAddress(wait).trim(), "Error: The message is not was expected! ");


    }
}
